#!/usr/bin/perl -w

use strict;
use DBI;
use CGI qw(:all);
use Foozeball;

my @teams = (
  'DREW BREES IS KING',
  'Dublin Tundra Wookies',
  'Niner Knights',
  'Death Blow',
  'Linkstrs Bills',
  'Armenia',
#  'Bangarang Rufio',
  'Death To Armenia',
  'Here Comes Da Pain',
  'East Bay Gotham Knights',
  'Mantooth Saints',
  'The Bam Bam Bigaloes'
);

my $round;
my $team;

my $server = 'localhost';
my $db = 'ffl_2011';
my $username = 'ffl';
my $password = 'foozeball';
my $dbh = DBI->connect("dbi:mysql:$db:$server", $username, $password);

print header();
print start_html("DJFFL Draft Central");

print "<body bgcolor=\"#132C06\" link=\"#FFFF80\" vlink=\"#FFFF80\" alink=\"#FFFF80\">\n";
print "<font face=\"Verdana\" color=\"#FFFFDF\">\n";

print "<h1><center><font face=\"Verdana\" color=\"#FFFF80\">2011 Draft Central</font></center></h1>\n";

print "<table border=\"5\" width=\"100%\">";
print "<tr>\n";
print "<td width=\"9%\" height=\"38\"></td>\n";

# print the teams across the top of the table
foreach $team (@teams)
{
  print "<td width=\"11%\" height=\"38\"><center><b><a href=\"./teams.cgi?f_team=$team&f_order=total_pts\">$team</a></b></center></td>\n";
}
print "</tr>\n";

for ($round = 1; $round < 15; $round++)
{
  print "<tr>\n";
  print "  <td width=\"9%\" height=\"19%\"><b><font color=\"#FFFFDF\">Round $round</font></b></td>\n";

  foreach $team (@teams)
  {
    my $sql = "select player,nfl_team from draft where round = $round and ffl_team = '$team';";
    my $sth = $dbh->prepare($sql);
    $sth->execute();

    my $row = $sth->fetchrow_arrayref;

    if ($team eq 'Death To Armenia' && $round > 11) 
    {
      #print "<td width=\"11%\" height=\"19\"><font color=\"#046EFE\">$row->[0] - $row->[1]</font></td>\n";
      print "<td width=\"11%\" height=\"19\"><font color=\"#FF0000\"><center>XXX</center></font></td>\n";
    }
    elsif ($team eq 'Armenia' && $round > 11)
    {
      #print "<td width=\"11%\" height=\"19\"><font color=\"#046EFE\">$row->[0] - $row->[1]</font></td>\n";
      print "<td width=\"11%\" height=\"19\"><font color=\"#FF0000\"><center>XXX</center></font></td>\n";
    }
    elsif ($team eq 'Bangarang Rufio' && $round > 13)
    {
      #print "<td width=\"11%\" height=\"19\"><font color=\"#046EFE\">$row->[0] - $row->[1]</font></td>\n";
      print "<td width=\"11%\" height=\"19\"><font color=\"#FF0000\"><center>XXX</center></font></td>\n";
    }
    elsif ($team eq 'Death Blow' && $round > 14)
    {
      #print "<td width=\"11%\" height=\"19\"><font color=\"#046EFE\">$row->[0] - $row->[1]</font></td>\n";
      print "<td width=\"11%\" height=\"19\"><font color=\"#FF0000\"><center>XXX</center></font></td>\n";
    }
    elsif ($team eq 'DREW BREES IS KING' && $round > 13)
    {
      #print "<td width=\"11%\" height=\"19\"><font color=\"#046EFE\">$row->[0] - $row->[1]</font></td>\n";
      print "<td width=\"11%\" height=\"19\"><font color=\"#FF0000\"><center>XXX</center></font></td>\n";
    }
    elsif ($team eq 'East Bay Gotham Knights' && $round > 12)
    {
      #print "<td width=\"11%\" height=\"19\"><font color=\"#046EFE\">$row->[0] - $row->[1]</font></td>\n";
      print "<td width=\"11%\" height=\"19\"><font color=\"#FF0000\"><center>XXX</center></font></td>\n";
    }
    elsif ($team eq 'Here Comes Da Pain' && $round > 13)
    {
      #print "<td width=\"11%\" height=\"19\"><font color=\"#046EFE\">$row->[0] - $row->[1]</font></td>\n";
      print "<td width=\"11%\" height=\"19\"><font color=\"#FF0000\"><center>XXX</center></font></td>\n";
    }
    elsif ($team eq 'Linkstrs Bills' && $round > 14)
    {
      #print "<td width=\"11%\" height=\"19\"><font color=\"#046EFE\">$row->[0] - $row->[1]</font></td>\n";
      print "<td width=\"11%\" height=\"19\"><font color=\"#FF0000\"><center>XXX</center></font></td>\n";
    }
    elsif ($team eq 'Mantooth Saints' && $round > 13)
    {
      #print "<td width=\"11%\" height=\"19\"><font color=\"#046EFE\">$row->[0] - $row->[1]</font></td>\n";
      print "<td width=\"11%\" height=\"19\"><font color=\"#FF0000\"><center>XXX</center></font></td>\n";
    }
    elsif ($team eq 'Niner Knights' && $round >= 13)
    {
      #print "<td width=\"11%\" height=\"19\"><font color=\"#046EFE\">$row->[0] - $row->[1]</font></td>\n";
      print "<td width=\"11%\" height=\"19\"><font color=\"#FF0000\"><center>XXX</center></font></td>\n";
    }
    elsif ($team eq 'The Bam Bam Bigaloes' && $round > 12)
    {
      #print "<td width=\"11%\" height=\"19\"><font color=\"#046EFE\">$row->[0] - $row->[1]</font></td>\n";
      print "<td width=\"11%\" height=\"19\"><font color=\"#FF0000\"><center>XXX</center></font></td>\n";
    }
    elsif ($team eq 'Dublin Tundra Wookies' && $round > 13)
    {
      #print "<td width=\"11%\" height=\"19\"><font color=\"#046EFE\">$row->[0] - $row->[1]</font></td>\n";
      print "<td width=\"11%\" height=\"19\"><font color=\"#FF0000\"><center>XXX</center></font></td>\n";
    }
    else
    {
      print "<td width=\"11%\" height=\"19\"><font color=\"#FFFFDF\">$row->[0] - $row->[1]</font></td>\n";
    }
  }
}

print "</tr>\n";

print "<tr>\n";
print "  <td width=\"9%\" height=\"19%\"><b><font color=\"#FFFFDF\">Current<br>Salary</font></b></td>\n";

foreach $team (@teams)
{
  my $salary = Foozeball::calc_salary($team);

  my $money_sql = "select salarycap from managers where ffl_team = '$team';";
  my $money_sth = $dbh->prepare($money_sql);
  $money_sth->execute();

  my $row = $money_sth->fetchrow_arrayref;
  my $money_left = $row->[0] - $salary;;

  if ($money_left < 0)
  {
    print "  <td width=\"11%\" height=\"19\"><center><font color=\"#FF0000\">\$$salary<br>(\$$money_left left)</font></center></td>\n";
  }
  else
  {
    print "  <td width=\"11%\" height=\"19\"><center><font color=\"#FFFFDF\">\$$salary<br>(\$$money_left left)</font></center></td>\n";
  }
}

print "</tr>\n";
print "</table>\n";

print end_html();
