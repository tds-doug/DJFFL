#!/usr/bin/perl -w

use strict;
use DBI;
use CGI qw(:all);

print header();
print start_html("Fantasy Football Records");

print "<body bgcolor=\"#132C06\" link=\"#FFFF80\" vlink=\"#FFFF80\" alink=\"#FFFF80\">\n";
print "<font face=\"Verdana\" color=\"#FFFFDF\">\n";

print "<h1><center><font face=\"Verdana\" color=\"#FFFF80\">Fantasy Football Hall of Records</font></center></h1>\n";

print "<table align=\"center\" border=\"5\" width=\"80%\">";
print "<tr>\n";
print "<td width=\"30%\"><center><b><font color=\"#FFFFDF\">Record</font></b></center></td>\n";
print "<td width=\"10%\"><center><b><font color=\"#FFFFDF\">FFL Season</font></b></center></td>\n";
print "<td width=\"60%\"><center><b><font color=\"#FFFFDF\">Record Holder(s)</font></b></center></td>\n";
print "<tr>\n";

my $server = 'localhost';
my $db = 'ffl_2011';
my $username = 'ffl';
my $password = 'foozeball';

my $dbh = DBI->connect("dbi:mysql:$db:$server", $username, $password);
my $sql = "select * from records order by id asc;";
my $sth = $dbh->prepare($sql);
$sth->execute();

while (my $row = $sth->fetchrow_arrayref)
{
  print "<tr>\n";
  print "<td width=\"30%\"><center><b><font color=\"#FFFFDF\">$row->[1]</font></b></center></td>\n";
  print "<td width=\"10%\"><center><b><font color=\"#FFFFDF\">$row->[2]</font></b></center></td>\n";
  print "<td width=\"60%\"><center><b><font color=\"#FFFFDF\">$row->[3]</font></b></center></td>\n";
  print "<tr>\n";
}

print "</table>\n";

print end_html();
