#!/usr/bin/perl -w

use strict;
use DBI;
use CGI qw(:all);
use Foozeball;

my $week = Foozeball::getweek();
my $lastweek = $week - 1;
my $nextweek = $week + 1;

#my $transactions = 'Processed';
#my $transactions = 'Not Processed';
#my $transactions = 'No More for the season!!!';
my $transactions = 'The season starts Sept 8.';

my $stats = 'The season starts Sept 8.';
#my $stats = 'Uploaded';
#my $stats = 'Uploaded thru Sunday';
#my $stats = 'Not Uploaded';

my $server = 'localhost';
my $db = 'ffl_2011';
my $username = 'ffl';
my $password = 'foozeball';

my $dbh = DBI->connect("dbi:mysql:$db:$server", $username, $password);

my $ffl_manager = $ENV{'REMOTE_USER'};
my $ffl_team = Foozeball::get_ffl_team($ffl_manager);

print header();
print start_html("Fantasy Football Main Page");

print "<body bgcolor=\"#132C06\" link=\"#FFFF80\" vlink=\"#FFFF80\" alink=\"#FFFF80\">\n";
print "<font face=\"Verdana\" color=\"#FFFFDF\">\n";

# TOP OF PAGE

print "<center><h1><blink>FFL Draft is Wednesday September 7 at 6PM PST!!!</blink></h1></center><p>\n";
print "<center><h2>NFL 2011 First Game: September 8 at 5:30PM PST</h2></center>\n";
print "<p><hr><p>\n";

print "<center><h3>FFL 2010 FFL Bowl Winner: The Bam Bam Bigaloes</h3></center>\n";
print "<center><h4>FFL 2010 Toilet Bowl Winner: DREW BREES IS KING</h4></center>\n";
print "<p><hr><p>\n";


print "<table width=\"100%\">";
print "<tr>\n";

print "<td>\n";
print "<h3><font face=\"Verdana\" color=\"#FFFF80\"><center>Weekly League Status</center></font></h3><p>\n";
print "</td>\n";
print "<td>\n";
print "<h3><font face=\"Verdana\" color=\"#FFFF80\"><center>Your Matchups</center></font></h3><p>\n";
print "</td>\n";
print "</tr>\n";

print "<tr>\n";

# LEAGUE STATUS SECTION
# Either "Season Has Not Started" or week #
print "<td>\n";
print "<font face=\"Verdana\" color=\"#FFFF80\">Current Week: </font><font face=\"Verdana\" color=\"#FFFFDF\">$week</font><p>\n";

# Status: Not Processed / Processed 
print "<font face=\"Verdana\" color=\"#FFFF80\">Week $week Transactions: </font><font face=\"Verdana\" color=\"#FFFFDF\">$transactions</font><p>\n";

# Status: Not Uploaded / Not Completed / Uploaded / None
#if($lastweek eq '0')
if($lastweek == 0)
{
  print "<font face=\"Verdana\" color=\"#FFFF80\">Week 1 Stats: </font><font face=\"Verdana\" color=\"#FFFFDF\">$stats</font>\n";
}
else
{
  print "<font face=\"Verdana\" color=\"#FFFF80\">Week $lastweek Stats: </font><font face=\"Verdana\" color=\"#FFFFDF\">$stats</font>\n";
}

print "<p>\n";

# ZOMBIE KILL OF THE WEEK SECTION
print "<img src=\"http://www.djffl.net/images/zombie_sm.jpg\"><font face=\"Verdana\" color=\"#FFFF80\"><a href=\"./zombie.cgi\">Zombie Kill</a> of the Week (Week $lastweek)</font>\n";

my $sql_zombie = "select * from zombie_kills where week = $lastweek;";
my $sth_zombie = $dbh->prepare($sql_zombie);
$sth_zombie->execute();

print "<table border=\"0\" width=\"80%\">\n";
print "<tr>\n";
print "<td><font face=\"Verdana\" color=\"#FFFFDF\"><center><u>Killer</u></center></font></td>\n";
print "<td><font face=\"Verdana\" color=\"#FFFFDF\"><center><u>Killee</u></center></font></td>\n";
print "<td><font face=\"Verdana\" color=\"#FFFFDF\"><center><u>Killed By</u></center></font></td>\n";
print "</tr>\n";

#while (my $row_zombie = $sth_zombie->fetchrow_arrayref)
#{
my $row_zombie = $sth_zombie->fetchrow_arrayref;
  print "<tr>\n";
  print "<td><font face=\"Verdana\" color=\"#FFFFDF\"><center>$row_zombie->[1]</center></font></td>\n";
  print "<td><font face=\"Verdana\" color=\"#FFFFDF\"><center>$row_zombie->[2]</center></font></td>\n";
  print "<td><font face=\"Verdana\" color=\"#FFFFDF\"><center>$row_zombie->[4] pts</center></font></td>\n";
  print "</tr></table>\n";
#}
# END ZOMBIE KILL OF THE WEEK SECTION

print "</td>\n";

# YOUR MATCHUP SECTION
print "<td>\n";
print "<table border=\"1\" width=\"80%\">";
print "<td><font face=\"Verdana\" color=\"#FFFFDF\"><center><b>Week</center></b></font></td>\n";
print "<td><font face=\"Verdana\" color=\"#FFFFDF\"><center><b>Home Team</center></b></font></td>\n";
print "<td><font face=\"Verdana\" color=\"#FFFFDF\"><center><b>Away Team</center></b></font></td>\n";
print "<td><font face=\"Verdana\" color=\"#FFFFDF\"><center><b>Outcome</center></b></font></td>\n";

# Last week Matchup
my $sql_last = "select * from schedule where week = $lastweek and (home_team = '$ffl_team' or away_team = '$ffl_team');";
my $sth_last = $dbh->prepare($sql_last);
$sth_last->execute();

print "<tr>\n";
while (my $row = $sth_last->fetchrow_arrayref)
{
  print "<tr>\n";
  print "<td width=\"10%\"><center><font color=\"#FFFFDF\">$row->[0]</font></center></td>\n";
  print "<td width=\"40%\"><center><font color=\"#FFFFDF\">$row->[1]</font></center></td>\n";
  print "<td width=\"40%\"><center><font color=\"#FFFFDF\">$row->[2]</font></center></td>\n";
  print "<td width=\"10%\"><center><font color=\"#FFFFDF\">$row->[3]</font></center></td>\n";
  print "<tr>\n";
}
print "</tr>\n";

# This week Matchup
my $sql_current = "select * from schedule where week = $week and (home_team = '$ffl_team' or away_team = '$ffl_team');";
my $sth_current = $dbh->prepare($sql_current);
$sth_current->execute();

print "<tr>\n";
while (my $row = $sth_current->fetchrow_arrayref)
{
  print "<tr>\n";
  print "<td width=\"10%\"><center><font color=\"#FFFFDF\">$row->[0]</font></center></td>\n";
  print "<td width=\"40%\"><center><font color=\"#FFFFDF\">$row->[1]</font></center></td>\n";
  print "<td width=\"40%\"><center><font color=\"#FFFFDF\">$row->[2]</font></center></td>\n";
  print "<td width=\"10%\"><center><font color=\"#FFFFDF\">$row->[3]</font></center></td>\n";
  print "<tr>\n";
}
print "</tr>\n";

# Next week Matchup
my $sql_next = "select * from schedule where week = $nextweek and (home_team = '$ffl_team' or away_team = '$ffl_team');";
my $sth_next = $dbh->prepare($sql_next);
$sth_next->execute();

print "<tr>\n";
while (my $row = $sth_next->fetchrow_arrayref)
{
  print "<tr>\n";
  print "<td width=\"10%\"><center><font color=\"#FFFFDF\">$row->[0]</font></center></td>\n";
  print "<td width=\"40%\"><center><font color=\"#FFFFDF\">$row->[1]</font></center></td>\n";
  print "<td width=\"40%\"><center><font color=\"#FFFFDF\">$row->[2]</font></center></td>\n";
  print "<td width=\"10%\"><center><font color=\"#FFFFDF\">$row->[3]</font></center></td>\n";
  print "<tr>\n";
}
print "</tr>\n";

print "</table>\n";
print "</td>\n";

print "</table>\n";

print "<p><hr><p>\n";

print "<h2><center>FFL Draft is Wednesday September 7 at 6PM PST!!!</center></h2><p>\n";
print "<center>It\'s on you to ensure your AIM instant messenger client works.  Failure to do so prior to the start of the draft results in a $10 salary penalty.</center><p>\n";

print "<p><hr><p>\n";

# SMACK TALK SECTION
print "<center><h3><font face=\"Verdana\" color=\"#FFFF80\">Recent <a href=\"./messages.cgi\">Smack Talk</a></font></h3></center>\n";

my $sql = "select * from messages order by id desc limit 10;";
#my $sql = "select * from messages where week = $week order by id desc;";
my $sth = $dbh->prepare($sql);
$sth->execute();

print "<table align=center border=\"1\" width=\"80%\">";
print "<tr>\n";
print "<td width=\"20%\"><center><b><font color=\"#FFFF80\">Team Name</font></b></center></td>\n";
print "<td width=\"80%\"><center><b><font color=\"#FFFF80\">Message</font></b></center></td>\n";
print "<tr>\n";

while (my $row = $sth->fetchrow_arrayref)
{
  print "<tr>\n";

  if($row->[1] eq 'Armenia')
  {
    print "<td width=\'15%\'><center><font color=\"#FF00FF\">$row->[1]</font></center></td>\n";
  }
  else
  {
  print "<td width=\"20%\"><center><font color=\"#FFFFDF\">$row->[1]</font></center></td>\n";
  }
  my $message = $row->[4] . $row->[5] . $row->[6];
  print "<td width=\"80%\"><font color=\"#FFFFDF\">$message</font></td>\n";
  print "<tr>\n";
}

print "</table>\n";

#print "<p><hr><p>\n";

#print "<center><h3><font face=\"Verdana\" color=\"#FFFF80\">2011 Playoff Picture</font></h3></center><p>\n";

#print "<u>Week 14</u><br>\n";
#print "Quarter Final Match (QF1) - Death To Armenia (4) vs The Bam Bam Bigaloes (5)<br>\n";
#print "Quarter Final Match (QF2) - Here Comes Da Pain (3) vs Bangarang Rufio (6)<br>\n";
#print "Toilet Bowl - Dublin Tundra Wookies vs DREW BREES IS KING<br>\n";
#print "<p>\n";

#print "<u>Week 15</u><br>\n";
#print "Semi Final Match (SF1) - East Bay Gotham Knights (1) vs Winner of QF1<br>\n";
#print "Semi Final Match (SF2) - Mantooth Saints (2) vs Winner of QF2<br>\n";
#print "<p>\n";

#print "<u>Week 16</u><br>\n";
#print "Fantasy Bowl - Winner of SF1 vs Winner of SF2\n";

print "<p><hr><p>\n";

print "<center><font face=\"Verdana\" color=\"#FFFF80\"><h3>Commish Note</h3></font></center>\n";

print "After much deliberation and consternation I have changed the league from a 4 team per conference 3 conference league to a 3 team per conference 4 conference league.  The playoffs will go top 4 teams go in and the next 2 teams, no matter what conference they are in, will be the wild cards.  I will word up the rules sometime between now and September 7.\n";

print "<p>\n";

print "Given that every year I remind people to check that their AOL Instant Messenger Clients will work with my group chat tool and every year someone does not, then whines about how they don\'t know how to fix it and the draft is delayed, I have decided to implement a \$10 salary penatly for anyone who\'s IM client does not work and has not tested it with me previously.  There are 3 weeks till the draft.  If you cannot test it then you are bloody lazy.\n";

print "<p><hr><p>\n";


print "Teams that have confirmed they will play this year so far:<p>\n";
print "<ul>\n";
print "<li>Armenia</li>\n";
print "<li>Death Blow</li>\n";
print "<li>Death To Armenia</li>\n";
print "<li>DREW BREES IS KING</li>\n";
print "<li>East Bay Gotham Knights</li>\n";
print "<li>Here Comes Da Pain</li>\n";
print "<li>Linkstrs Bills</li>\n";
print "<li>Mantooth Saints</li>\n";
print "<li>Niner Knights</li>\n";
print "<li>The Bam Bam Bigaloes</li>\n";
print "<li>Dublin Tundra Wookies</li>\n";
print "</ul>\n";

print "Teams that have <b>NOT</b> confirmed they will play this year:<p>\n";
print "<ul>\n";
print "<li>Bangarang Rufio</li>\n";
print "</ul>\n";

print "<p><hr><p>\n";

# BYE WEEK SECTION
print "<center><h3><font face=\"Verdana\" color=\"#FFFF80\">NFL Teams With A Bye This Week</font></h3></center>\n";

#print "<center>\n";

print "No byes until week 5.\n";
#print "No more byes until next season!\n";

#print "<table border=\"0\" cellpadding=\"0\" cellspacking=\"0\" style=\"border-collapse: collapse\" width=\"60%\">\n";
#print "<tr>\n";
#print "  <td><center><img src=\"http://www.djffl.net/images/GB.gif\"></center></td>\n";
#print "  <td><center><img src=\"http://www.djffl.net/images/NO.gif\"></center></td>\n";
#print "  <td><center><img src=\"http://www.djffl.net/images/Oak.gif\"></center></td>\n";
#print "  <td><center><img src=\"http://www.djffl.net/images/SD.gif\"></center></td>\n";
#print "</tr>\n";
#print "<tr>\n";
#print "  <td><center><font color=\"#FFFFDF\">Green Bay</font></center></td>\n";
#print "  <td><center><font color=\"#FFFFDF\">New Orleans</font></center></td>\n";
#print "  <td><center><font color=\"#FFFFDF\">Oakland</font></center></td>\n";
#print "  <td><center><font color=\"#FFFFDF\">San Diego</font></center></td>\n";
#print "</tr>\n";
#print "</table>\n";

#print "</center>\n";

print "<p><hr><p>\n";

print "<center><h3><font face=\"Verdana\" color=\"#FFFF80\">League WebSite Changes</font></h3></center>\n";

print "<ol>\n";
print "<li>Updated 2011 FFL schedule</li>\n";
print "<li>Removed inactive players from database</li>\n";
print "<li>Updated players salaries</li>\n";
print "<li>Changed conference standings</li>\n";
print "<li>Updated player contracts</li>\n";
print "</ol>\n";

print end_html();
