#!/usr/bin/perl -w

use strict;
use DBI;
use CGI qw(:all);
use Foozeball;

my $week = Foozeball::getweek();
my $lastweek = $week - 1;
my $nextweek = $week + 1;

my $transactions = 'Processed';
#my $transactions = 'Not Processed';
#my $transactions = 'No More for the season!!!';
#my $transactions = 'The season starts Sept 9.';

#my $stats = 'The season starts Sept 9.';
my $stats = 'Uploaded';
#my $stats = 'Uploaded thru Sunday';
#my $stats = 'Not Uploaded';

my $server = 'localhost';
my $db = 'ffl_2011';
my $username = 'ffl';
my $password = 'foozeball';

my $dbh = DBI->connect("dbi:mysql:$db:$server", $username, $password);

my $ffl_manager = $ENV{'REMOTE_USER'};
my $ffl_team = Foozeball::get_ffl_team($ffl_manager);

print header();
print start_html("Fantasy Football Main Page");

print "<body bgcolor=\"#132C06\" link=\"#FFFF80\" vlink=\"#FFFF80\" alink=\"#FFFF80\">\n";
print "<font face=\"Verdana\" color=\"#FFFFDF\">\n";

# TOP OF PAGE

#print "<center><h1>NFL 2011 First Game: <blink>September 9 at 5:30PM PST</blink></h1></center>\n";
#print "<p><hr><p>\n";

#print "<center><h3>FFL 2009 FFL Bowl Winner: The Bam Bam Bigaloes</h3></center>\n";
#print "<center><h4>FFL 2009 Toilet Bowl Winner: East Bay Gotham Knights</h4></center>\n";
print "<p><hr><p>\n";


print "<table width=\"100%\">";
print "<tr>\n";

print "<td>\n";
print "<h3><font face=\"Verdana\" color=\"#FFFF80\"><center>Weekly League Status</center></font></h3><p>\n";
print "</td>\n";
print "<td>\n";
print "<h3><font face=\"Verdana\" color=\"#FFFF80\"><center>Your Matchups</center></font></h3><p>\n";
print "</td>\n";
print "</tr>\n";

print "<tr>\n";

# LEAGUE STATUS SECTION
# Either "Season Has Not Started" or week #
print "<td>\n";
print "<font face=\"Verdana\" color=\"#FFFF80\">Current Week: </font><font face=\"Verdana\" color=\"#FFFFDF\">$week</font><p>\n";

# Status: Not Processed / Processed 
print "<font face=\"Verdana\" color=\"#FFFF80\">Week $week Transactions: </font><font face=\"Verdana\" color=\"#FFFFDF\">$transactions</font><p>\n";

# Status: Not Uploaded / Not Completed / Uploaded / None
#if($lastweek eq '0')
if($lastweek == 0)
{
  print "<font face=\"Verdana\" color=\"#FFFF80\">Week 1 Stats: </font><font face=\"Verdana\" color=\"#FFFFDF\">$stats</font>\n";
}
else
{
  print "<font face=\"Verdana\" color=\"#FFFF80\">Week $lastweek Stats: </font><font face=\"Verdana\" color=\"#FFFFDF\">$stats</font>\n";
}

print "<p>\n";

# ZOMBIE KILL OF THE WEEK SECTION
my $sql_zombie = "select * from zombie_kills where week = $lastweek;";
my $sth_zombie = $dbh->prepare($sql_zombie);
$sth_zombie->execute();

my $row_zombie = $sth_zombie->fetchrow_arrayref;
#print "<font face=\"Verdana\" color=\"#FFFF80\">Zombie Kill for Week $lastweek:</font><font face=\"Verdana\" color=\"#FFFFDF\"> $row_zombie->[1] killed $row_zombie->[2] by <font color=\"#FF0000\">$row_zombie->[4]</font> pts!!!</font>\n";
print "<img src=\"http://www.djffl.net/images/zombie_sm.jpg\"><font face=\"Verdana\" color=\"#FFFF80\">Zombie Kill for Week $lastweek:</font><font face=\"Verdana\" color=\"#FFFFDF\"> $row_zombie->[1] killed $row_zombie->[2] by <font color=\"#FF0000\">$row_zombie->[4]</font> pts!!!</font>\n";
# END ZOMBIE KILL OF THE WEEK SECTION

print "</td>\n";

# YOUR MATCHUP SECTION
print "<td>\n";
print "<table border=\"1\" width=\"80%\">";
print "<td><font face=\"Verdana\" color=\"#FFFFDF\"><center><b>Week</center></b></font></td>\n";
print "<td><font face=\"Verdana\" color=\"#FFFFDF\"><center><b>Home Team</center></b></font></td>\n";
print "<td><font face=\"Verdana\" color=\"#FFFFDF\"><center><b>Away Team</center></b></font></td>\n";
print "<td><font face=\"Verdana\" color=\"#FFFFDF\"><center><b>Outcome</center></b></font></td>\n";

# Last week Matchup
my $sql_last = "select * from schedule where week = $lastweek and (home_team = '$ffl_team' or away_team = '$ffl_team');";
my $sth_last = $dbh->prepare($sql_last);
$sth_last->execute();

print "<tr>\n";
while (my $row = $sth_last->fetchrow_arrayref)
{
  print "<tr>\n";
  print "<td width=\"10%\"><center><font color=\"#FFFFDF\">$row->[0]</font></center></td>\n";
  print "<td width=\"40%\"><center><font color=\"#FFFFDF\">$row->[1]</font></center></td>\n";
  print "<td width=\"40%\"><center><font color=\"#FFFFDF\">$row->[2]</font></center></td>\n";
  print "<td width=\"10%\"><center><font color=\"#FFFFDF\">$row->[3]</font></center></td>\n";
  print "<tr>\n";
}
print "</tr>\n";

# This week Matchup
my $sql_current = "select * from schedule where week = $week and (home_team = '$ffl_team' or away_team = '$ffl_team');";
my $sth_current = $dbh->prepare($sql_current);
$sth_current->execute();

print "<tr>\n";
while (my $row = $sth_current->fetchrow_arrayref)
{
  print "<tr>\n";
  print "<td width=\"10%\"><center><font color=\"#FFFFDF\">$row->[0]</font></center></td>\n";
  print "<td width=\"40%\"><center><font color=\"#FFFFDF\">$row->[1]</font></center></td>\n";
  print "<td width=\"40%\"><center><font color=\"#FFFFDF\">$row->[2]</font></center></td>\n";
  print "<td width=\"10%\"><center><font color=\"#FFFFDF\">$row->[3]</font></center></td>\n";
  print "<tr>\n";
}
print "</tr>\n";

# Next week Matchup
my $sql_next = "select * from schedule where week = $nextweek and (home_team = '$ffl_team' or away_team = '$ffl_team');";
my $sth_next = $dbh->prepare($sql_next);
$sth_next->execute();

print "<tr>\n";
while (my $row = $sth_next->fetchrow_arrayref)
{
  print "<tr>\n";
  print "<td width=\"10%\"><center><font color=\"#FFFFDF\">$row->[0]</font></center></td>\n";
  print "<td width=\"40%\"><center><font color=\"#FFFFDF\">$row->[1]</font></center></td>\n";
  print "<td width=\"40%\"><center><font color=\"#FFFFDF\">$row->[2]</font></center></td>\n";
  print "<td width=\"10%\"><center><font color=\"#FFFFDF\">$row->[3]</font></center></td>\n";
  print "<tr>\n";
}
print "</tr>\n";

print "</table>\n";
print "</td>\n";

print "</table>\n";

print "<p><hr><p>\n";

# SMACK TALK SECTION
print "<center><h3><font face=\"Verdana\" color=\"#FFFF80\">Recent Smack Talk</font></h3></center>\n";

my $sql = "select * from messages order by id desc limit 5;";
my $sth = $dbh->prepare($sql);
$sth->execute();

print "<table align=center border=\"1\" width=\"80%\">";
print "<tr>\n";
print "<td width=\"20%\"><center><b><font color=\"#FFFFDF\">Team Name</font></b></center></td>\n";
print "<td width=\"80%\"><center><b><font color=\"#FFFFDF\">Message</font></b></center></td>\n";
print "<tr>\n";

while (my $row = $sth->fetchrow_arrayref)
{
  print "<tr>\n";

  if($row->[1] eq 'Armenia')
  {
    print "<td width=\'15%\'><center><font color=\"#FF00FF\">$row->[1]</font></center></td>\n";
  }
  else
  {
  print "<td width=\"20%\"><center><font color=\"#FFFFDF\">$row->[1]</font></center></td>\n";
  }
  my $message = $row->[3] . $row->[4] . $row->[5];
  print "<td width=\"80%\"><font color=\"#FFFFDF\">$message</font></td>\n";
  print "<tr>\n";
}

print "</table>\n";

print "<p><hr><p>\n";

print "<center><font face=\"Verdana\" color=\"#FFFF80\"><h3>Commish Note</h3></font></center>\n";

print "Note that the conferences have been reworked to create a better sense fo rivalry thoughout the season.<p>\n";

print "At Shay's suggestion I have added each manager's real name next to the team name in the Matchup Page and the drop down for the FFL Teams tool.  Unless someone thinks it looks too funky will leave it up for the rest of the season.\n";

#print "Teams that have confirmed they will play this year so far:<p>\n";
#print "<ul>\n";
#print "<li>Armenia</li>\n";
#print "<li>Death Blow</li>\n";
#print "<li>Death To Armenia</li>\n";
#print "</ul>\n";

#print "Teams that have confirmed they will <b>NOT</b> play this year:<p>\n";
#print "<ul>\n";
#print "<li>Raider Nation</li>\n";
#print "</ul>\n";

print "<p><hr><p>\n";

#print "<center><h3>2011 Playoff Picture</h3></center><p>\n";
#print "<u>Week 14</u><br>\n";
#print "Quarter Final Match (QF1) - Mantooth Saints (4) vs Niner Knights (5)<br>\n";
#print "Quarter Final Match (QF2) - Here Comes Da Pain (3) vs The Bam Bam Bigaloes (6)<br>\n";
#print "Toilet Bowl - Dublin Tundra Wookies vs East Bay Gotham Knights<br>\n";
#print "<p>\n";
#
#print "<u>Week 15</u><br>\n";
#print "Semi Final Match (SF1) - DREW BREES IS KING (1) vs The Bam Bam Bigaloes (6)<br>\n";
#print "Semi Final Match (SF2) - <font color=\"#FF00FF\">Armenia</font> (2) vs Mantooh Saints (4)<br>\n";
#print "<p>\n";
#
#print "<u>Week 16</u><br>\n";
#print "Fantasy Bowl - Mantooth Saints (4) vs The Bam Bam Bigaloes (6)\n";
#
#print "<p><hr><p>\n";

# BYE WEEK SECTION
print "<center><h3><font face=\"Verdana\" color=\"#FFFF80\">NFL Teams With A Bye This Week</font></h3></center>\n";

print "<center>\n";

print "No byes until week 4.\n";
#print "No more byes until next season!\n";

#print "<table border=\"0\" cellpadding=\"0\" cellspacking=\"0\" style=\"border-collapse: collapse\" width=\"60%\">\n";
#print "<tr>\n";
#print "  <td><center><img src=\"http://www.djffl.net/images/Buf.gif\"></center></td>\n";
#print "  <td><center><img src=\"http://www.djffl.net/images/Cle.gif\"></center></td>\n";
#print "  <td><center><img src=\"http://www.djffl.net/images/Min.gif\"></center></td>\n";
#print "  <td><center><img src=\"http://www.djffl.net/images/NYJ.gif\"></center></td>\n";
#print "  <td><center><img src=\"http://www.djffl.net/images/Oak.gif\"></center></td>\n";
#print "  <td><center><img src=\"http://www.djffl.net/images/StL.gif\"></center></td>\n";
#print "</tr>\n";
#print "<tr>\n";
#print "  <td><center><font color=\"#FFFFDF\">Buffalo</font></center></td>\n";
#print "  <td><center><font color=\"#FFFFDF\">Cleveland</font></center></td>\n";
#print "  <td><center><font color=\"#FFFFDF\">Minnesota</font></center></td>\n";
#print "  <td><center><font color=\"#FFFFDF\">New York</font></center></td>\n";
#print "  <td><center><font color=\"#FFFFDF\">Oakland</font></center></td>\n";
#print "  <td><center><font color=\"#FFFFDF\">St. Louis</font></center></td>\n";
#print "</tr>\n";
#print "</table>\n";

print "</center>\n";

print "<p><hr><p>\n";

print "<center><h3><font face=\"Verdana\" color=\"#FFFF80\">League Changes</font></h3></center>\n";

print "<ol>\n";
print "<li>Clarified rules on Injured Reserve (check League Rules -> Roster)</li>\n";
print "<li>Week 1 is a double header</li>\n";
print "<li>Added Draft Central</li>\n";
print "<li>Added Franchise Player tool</li>\n";
print "<li>Reorganized conferences</li>\n";
print "</ol>\n";

print end_html();
